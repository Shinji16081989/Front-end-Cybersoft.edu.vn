function showMessage()
{
  alert("3. script in file myScript.js")
}
