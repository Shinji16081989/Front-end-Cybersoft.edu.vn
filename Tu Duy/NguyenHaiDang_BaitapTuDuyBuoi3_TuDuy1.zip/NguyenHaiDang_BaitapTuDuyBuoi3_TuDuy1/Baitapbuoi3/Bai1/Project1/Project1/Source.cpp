﻿/* Một hộp sữa có thể chứa 3,78 lít sữa. Mỗi buổi sáng, một trang trại bò sữa đưa các hộp sữa đến một cửa hàng tạp hoá tại địa phương. Chi phí sản xuất một lít sữa là 0,38 đô la, 
và lợi nhuận của mỗi hộp sữa là 0,27 đô la. Viết chương trình thực hiện những việc sau:

a. Nhắc người dùng nhập tổng số lượng sữa được sản xuất vào buổi sáng.
b. Xuất ra số lượng hộp sữa cần thiết để giữ sữa. (Đưa ra câu trả lời cho số nguyên gần nhất.)
c. Xuất ra chi phí sản xuất sữa.
d. Xuất ra lợi nhuận ước tính của số lượng sữa đã sản xuất.
*/
#include <iostream>

using namespace std;

const double ONE_BOX = 3.78;
const double FEE_PER_LITER = 0.38;
const double INCOME_PER_BOX = 0.27;

int main()
{
	int milkorder;
	int boxperday;
	double feetoproduct;
	double income;


	
}